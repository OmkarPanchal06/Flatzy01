import Navbar from "../../components/Navbar"
import Footer from "../../components/Footer"
import ChatBot from "../../components/ChatBot"

export default function Contact() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="py-20 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
        <p className="text-lg text-gray-600 mb-8">Get in touch with our team</p>
        <div className="max-w-md mx-auto">
          <p className="text-gray-600 mb-4">📧 support@flatzy.com</p>
          <p className="text-gray-600 mb-4">📞 +91 98765 43210</p>
          <p className="text-gray-600">📍 Bangalore, Karnataka</p>
        </div>
      </div>
      <Footer />
      <ChatBot />
    </div>
  )
}
