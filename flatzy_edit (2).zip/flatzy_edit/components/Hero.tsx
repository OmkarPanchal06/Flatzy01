"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Search, MapPin, DollarSign, Home, ChevronLeft, ChevronRight } from "lucide-react"

interface HeroProps {
  onSearch?: (searchData: { location: string; priceRange: string; propertyType: string }) => void
}

const Hero: React.FC<HeroProps> = ({ onSearch }) => {
  const [searchData, setSearchData] = useState({
    location: "",
    priceRange: "",
    propertyType: "",
  })

  // Image carousel data
  const carouselImages = [
    {
      id: 1,
      src: "https://thumbs.dreamstime.com/b/right-facing-rent-real-estate-sign-front-house-new-108277374.jpg",
      alt: "Rental Property Sign",
    },
    {
      id: 2,
      src: "https://cdn.home-designing.com/wp-content/uploads/2015/10/wood-paneling-apartment.jpg",
      alt: "Modern Apartment Interior",
    },
    {
      id: 3,
      src: "https://www.shutterstock.com/image-photo/hostel-dormitory-beds-arranged-room-260nw-696168130.jpg",
      alt: "Hostel Dormitory Room",
    },
    {
      id: 4,
      src: "https://cf.bstatic.com/xdata/images/hotel/max1024x768/547761545.jpg?k=ef8071da1c5e8c64c55a6a46841a6322e0ec0081d1a0b8e3aa4bd565a7e0960a&o=&hp=1",
      alt: "Hotel Room",
    },
    {
      id: 5,
      src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTSkVBHTLYUdqfa7dxCNVLeyJC4IemRkJezQ&s",
      alt: "Apartment Building",
    },
    {
      id: 6,
      src: "https://media-cdn.tripadvisor.com/media/photo-s/01/2c/9e/50/here-s-my-room.jpg",
      alt: "Cozy Room",
    },
    {
      id: 7,
      src: "https://cf.bstatic.com/xdata/images/hotel/max1024x768/494326118.jpg?k=2226376f838caccbba40354b9d85d4202a7a1cf093b9f9300f89f2314ab65633&o=&hp=1",
      alt: "Luxury Room",
    },
    {
      id: 8,
      src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFOjo-XR6wD54FszBh3WbPKd3V9S6dwZoD5g&s",
      alt: "Property Exterior",
    },
  ]

  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  // Auto-advance carousel every 3 seconds
  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % carouselImages.length)
    }, 3000) // 3 seconds

    return () => clearInterval(interval)
  }, [isAutoPlaying, carouselImages.length])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (onSearch) {
      onSearch(searchData)
    } else {
      console.log("Search data:", searchData)
    }
  }

  const goToSlide = (index: number) => {
    setCurrentImageIndex(index)
    setIsAutoPlaying(false)
    // Resume auto-play after 5 seconds
    setTimeout(() => setIsAutoPlaying(true), 5000)
  }

  const goToPrevious = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + carouselImages.length) % carouselImages.length)
    setIsAutoPlaying(false)
    setTimeout(() => setIsAutoPlaying(true), 5000)
  }

  const goToNext = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % carouselImages.length)
    setIsAutoPlaying(false)
    setTimeout(() => setIsAutoPlaying(true), 5000)
  }

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Background Carousel */}
      <div className="absolute inset-0">
        {carouselImages.map((image, index) => (
          <div
            key={image.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentImageIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.src = "/placeholder.svg?height=1080&width=1920"
              }}
            />
          </div>
        ))}
      </div>

      {/* Overlay for better text readability */}
      <div className="absolute inset-0 bg-black/50"></div>

      {/* Navigation Arrows */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300"
      >
        <ChevronLeft size={24} />
      </button>

      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300"
      >
        <ChevronRight size={24} />
      </button>

      {/* Carousel Dots */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
        {carouselImages.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentImageIndex ? "bg-white scale-125" : "bg-white/50 hover:bg-white/75"
            }`}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <div className="text-center text-white px-4 max-w-4xl mx-auto animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-2xl text-shadow-lg">
            Find Your Next Rental Home
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-95 drop-shadow-xl text-shadow-md">
            Discover the perfect place to call home with our curated rental properties
          </p>

          {/* Search Bar */}
          <form
            onSubmit={handleSearch}
            className="bg-white/95 backdrop-blur-md rounded-lg p-4 md:p-6 shadow-2xl border border-white/30"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Location Input */}
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Enter location"
                  value={searchData.location}
                  onChange={(e) => setSearchData({ ...searchData, location: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-transparent text-gray-900"
                />
              </div>

              {/* Price Range */}
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <select
                  value={searchData.priceRange}
                  onChange={(e) => setSearchData({ ...searchData, priceRange: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-transparent text-gray-900"
                >
                  <option value="">Price Range</option>
                  <option value="0-10000">₹0 - ₹10,000</option>
                  <option value="10000-25000">₹10,000 - ₹25,000</option>
                  <option value="25000-50000">₹25,000 - ₹50,000</option>
                  <option value="50000+">₹50,000+</option>
                </select>
              </div>

              {/* Property Type */}
              <div className="relative">
                <Home className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <select
                  value={searchData.propertyType}
                  onChange={(e) => setSearchData({ ...searchData, propertyType: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-transparent text-gray-900"
                >
                  <option value="">Property Type</option>
                  <option value="Flat">Flat</option>
                  <option value="Hostel">Hostel</option>
                  <option value="Room">Room</option>
                </select>
              </div>

              {/* Search Button */}
              <button
                type="submit"
                className="bg-sky-500 hover:bg-sky-600 text-white px-6 py-3 rounded-md font-medium flex items-center justify-center space-x-2 transition-colors shadow-lg"
              >
                <Search size={20} />
                <span>Search</span>
              </button>
            </div>
          </form>

          {/* Image Counter */}
          <div className="mt-6 text-white/80 text-sm">
            {currentImageIndex + 1} / {carouselImages.length}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Hero
